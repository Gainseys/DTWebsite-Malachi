<?php include("constants/header_nav.html"); ?>
		
		
		
		<div class="box main"> 
		<h3>Stressed Out?</h3>
		<p> Stress appears and expresses itself in different ways for different people therefore this page gives a brief preview of what hte other sections contain and why. The actual sections will however give more detial.</p>
			
			
			<p>Music: The music section has links to diferent music supplying sites and even some reccomendation of music, this is because research has shwon that listening to music can be an effective for help for relaxation and stress management.</p>

			<p>Schedule: The schedule section again has links to dfifferent tools to create a schedule but also has an in built schedule link for easier access directly on this website with the calendar having reccomendatons of things to do at what time.</p>

			<p>Meet The Professionals: This section is similar to contact however it leads to different groups be it websites or addresses of people that are better suited for instructions on what to do about stress.</p>

			<p>Contact: This section is how to contact me, the creator of this website, about any problems/ issues, or questions that you want to ask me.</p>

			<p>Please note that this website consists of multiple ways to manage your stress and ways to improve life in general and NOT how to completly get rid of stress, only how to manage it.</p>
			<p>This website was made around the basis of being used by children, teenagers, and students, however the useage of the presented applications/ support is not limited to the listed partys.</p>
			<p>Please remember to seek professional help if overly stressed as they are much better suited to handling issues related to stress than I am.
			Once again remember that this website is not the be all end all solution to stress, it simply suggests on how to improve your life.</p>
		</div> <!-- / main -->
		
		
		
		<div class="box side"> 
			<h2>Stress information</h2>
			<div class="center-image">
			<img class="img-circle" src="img/frog_boi.png" width="150" height="150"
           alt="frog boi">
				</div>
			
			
		<p>This list of websites below are multiple sources of information about stress and what causes it, the effects of it and more indepth ways on how to manage and reduce stress</p>
			
			
		<ul>
			
			<li><a href="https://www.mentalhealth.org.uk/a-to-z/s/stress">Mental Health Foundation</a></li>
			
			<li><a href="https://my.clevelandclinic.org/health/articles/11874-stress">Cleaveland Clinic</a></li>
			
			<li><a href="https://www.uofmhealth.org/health-library/uz2209">Michigan Health</a></li>
		
		</ul>
			
			
		</div> <!-- / side -->
		
		
<?php include("constants/footer.html"); ?>