<?php include("constants/header_nav.html"); ?>

<div class="box main">
	<div class="music">
	<iframe src="https://open.spotify.com/embed/playlist/37i9dQZF1DWVFeEut75IAL" width="1050" height="380" allow="encrypted-media"></iframe>
		<a href="https://open.spotify.com/">Spotify</a>
</div>
	</div>

<div class="box side">
    <h3>Music</h3>
	<div class="center-image">
		<img class="img-circle" src="img/music_girl.png" width="150" height="150"
			 alt="music girl"></div>
    <p>Music has been tested and even proven to be a significant stress releiver/recuer 
        that it is ighly reccomneded for any stressed out person to just take some time to stop what they're doing and listen to some of the more 'calming' music
        the genr/s that are usually classified as being relaxing/stress reducing is classical and jazz.
        Below are links to websites that have more detail about listening to music and its beneficial properties.
    </p>
    <ul>
        <li> <a href="https://www.northshore.org/healthy-you/9-health-benefits-of-music/">North Shore</a></li>
        
        <li> <a href="https://www.healthline.com/health/benefits-of-music#physical-benefits">Healthline</a></li>
        
        <li> <a href="https://www.verywellmind.com/how-to-use-music-for-stress-relief-3144689">Verywellmind</a></li>	
		
		</ul>
	
</div>

<?php include("constants/footer.html"); ?>