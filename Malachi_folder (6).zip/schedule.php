<?php include("constants/header_nav.html"); ?>

<div class="box main">
	<p>A good schedule plan is that on Monday, Tuesday, Wednesday, Thursday you should wake up at 6:00am. Between 4:00pm and 6:00pm you should do any work you have. Next between 7:00pm and 8:00pm you should do some exercises. And finally at 10:00pm you should go to bed. </p>
	<p>while on Friday you should do all that except you can go to bed at 11:00pm</p>
	<p>On Saturday and Sunday you should wake up at 8:00am, between 10:00am and 11:00am you should go for a walk. instead of doing any required work (if you have done all of it) between 4:00pm and 6:00pm you could do some hobby work. Instead of excersing between 7:00pm and 8:00pm you should do something relaxing. And finally go to sleep at 11:00pm except on Sundays where you should go to bed at 10:00pm</p>
	
	<div class="music">
	<a href="https://calendar.google.com/calendar">Google Calanders</a></div>
	<iframe src="https://docs.google.com/document/d/18pGmxpT2WYg9TzmWcR9PxtNRTKht__fhwZssTo9JK6o/edit?usp=sharing" width="1000" height="1000"></iframe> 
	
	
</div>

<div class="box side">
	<h3>Schedules</h3>
	<div class="center-image">
	<img class="img-circle" src="img/schedule.png" width="150" height="150"
		 alt="schedule"></div>
 <p>A good schedule / general rule of thumb for reducing stress is always a good idea as you can keep track of everything that your doing and plan some events easier such as when to do some recommended stress reducing actiites</p>
	<p>In the main area are some links to some good websites where you can put in your plans for your day</p>
</div>

<?php include("constants/footer.html"); ?>