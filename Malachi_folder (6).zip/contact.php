<?php include("constants/header_nav.html"); ?>

    <div class="box main">
        <div class="contact">
        <iframe src="https://docs.google.com/forms/d/e/1FAIpQLScWBt7K2dDDk-RTSzuOwFrysRCbiTuJ2vYvcpWPbKMHLA1E8g/viewform?embedded=true" width="640" height="641" ></iframe>
</div>

</div> <!-- main -->


    <div class="box side">
        
    <h2>About me</h2>
    
    <div class="center-image">
<img class="img-circle" src="img/space_is_calm.png" width="150" height="150"
           alt="Space">
        </div>
<div class="side-text">
    <p>Hi, my name is Malachi and I am the creator of this website. I created this website for two reasons the;</p>
         <p>first reason is because it is an assignment for my class so I have to do it.</p>
        <p> The second and much more improtant reason however is to help inform people and to help people figure out ways to reduce their own or somebody elses stress.</p>
         <p>Infact during the creation of this website I have been incredibly stressed myself but never had the oppurtunites to reduce my stress using the tactics shared in my other sections.</p>
        <p> This is because even if I did I would still have more stress later as the allocated time for the creation of the entire website is 3 weeks.</p>
        <p> Once this assignment is done I will take time to properly relax after a hard time of balancing 6 differnet classes each providing a lot of work.</p>
        <p> Stress has also been a prominant thing in my life especially in recent years and will continue to be but will have less impact in my daily life now because of the advice.</p>   <!-- Put information about making this and personnel experience with stress and a few fun facts -->
</div>
</div> <!-- side -->









<?php include("constants/footer.html"); ?>