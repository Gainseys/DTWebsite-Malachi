<?php include("constants/header_nav.html"); ?>

<div class="box main">
	<div class="music">
	<p>The links on this part of the page is for some more specific websites for the different areas that are listed in the side bar.</p>
<p>Auckland:</p>
<ul>
	
	<li> <a href="https://www.aucklandcitytherapy.co.nz/">Auckland city Therapy</a> </li>
	
	<li> <a href="https://www.healthline.com/health/stress-help">Healthline</a> </li>
	
	<li> <a href="https://www.changeit.co.nz/consultations/stress/">Change It</a> </li>	
	
	<li> <a href="https://www.healthnavigator.org.nz/health-a-z/s/stress-at-work/">Health Navigator</a> </li>
	
	<li> <a href="https://www.therapycounselling.net/stress">Therapy Counselling</a> </li>
	
	</ul>
		
<p>Christchurch:</p>
		
<ul>
	<li> <a href="https://christchurchtherapy.com/">Christchurch Therapy </a> </li>
	
	<li> <a href="https://merivaletherapy.co.nz/">Merival Therapy</a> </li>
	
	<li> <a href="https://www.lucidpsychotherapy.co.nz/">Lucid Psychotherapy</a> </li>
	
	<li> <a href="https://winchestercounselling.co.nz/">Winchester Counselling</a> </li>
	
	<li> <a href="https://www.talkingtherapy.co.nz/">Talking Therapy</a> </li>
	
	</ul>

		<p> Wellington:</p>
		
<ul>	
	
	<li> <a href="https://wwww.talkingworks.co.nz/dir/wellington/wellington.html">Welington Therapy</a> </li>	
	
	<li> <a href="https://anxietyspecialists.co.nz/">Anxiety Specialists</a> </li>
	
	<li> <a href="https://www.counsellingpsychotherapy.net.nz/depression-anxiety">Conselling Pyschotherapy</a> </li>
	
	<li> <a href="https://www.naturaltherapypages.co.nz/therapist/2337">Natural Therapy</a> </li>
		
	<li> <a href="https://welpa.co.nz/">Wellington Pyshocological Associates</a> </li>
	
	</ul>
		
</div></div>

<div class="box side">
    <h3>The Professionals</h3>
	<div class="center-image">
		<img class="img-circle" src="img/professional.png" width="150" height="150"
			 alt="professional"></div>
    <p>The professionals that are being refered to throughout this website are not nessaceraily people who are specicly researching and helping people with stress
		but mostly people that can help in a multitude off ways and not only with the direct resultant stress
		but can also help with combing through and helping you reach the solution to get rid of or reduce the impact that is put on you from a stress source.
		The best people that are qualified for this are therapists.
		So below are some general therapists for different New Zealand regins in general while the main page has area specifics.
    </p>
	<a href="https://www.aucklandcitytherapy.co.nz/">Auckland city Therapy</a>
	<a href="https://christchurchtherapy.com/">Christchurch Therapy </a>
	<a href="https://www.talkingworks.co.nz/dir/wellington/wellington.html">Wellington Therapy</a>
	<a href="https://dunedinpsychotherapy.co.nz/">Dunedin Therapy</a>
</div>

<?php include("constants/footer.html"); ?>